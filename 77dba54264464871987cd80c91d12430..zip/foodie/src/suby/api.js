export const API_URL = "https://quick-backend-nodejs.onrender.com"

// export const API_URL = "http://localhost:4000"